
public class Welcome 
{
	public static void main(String[] list)
	{
		System.out.println(list[0]+" Welcome to Java!");
	
		System.out.println("This is "+ list[1]+" Programe ");
		System.out.println("You are in Group-"+ list[2]);
		
		















		//Scanner myInput = new Scanner(System.in);
		//System.out.print("Enter Your Marks in Programming : ");
		//int Marks = myInput.nextInt();
		//System.out.println("Your Marks in Programming : "+ Marks);
  	}
}
