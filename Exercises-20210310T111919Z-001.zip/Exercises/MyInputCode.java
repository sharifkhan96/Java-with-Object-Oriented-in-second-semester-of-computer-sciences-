/*Taking INPUT in Java
There are many ways to take input in java from Keyboard/File
We will use Scanner class*/

import java.util.Scanner;

public class MyInputCode
{
	public static void main(String[] args)
	{
		Scanner myInput = new Scanner(System.in);

		int age;
		System.out.print("What is your Age : ");		
		age = myInput.nextInt();

		System.out.println("Your age is : "+age);
		age = age + 2;
		System.out.println("You will be "+age+" years old after 2 years");	
	}
}