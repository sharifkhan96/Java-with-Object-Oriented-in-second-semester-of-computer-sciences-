public class types
{
	public static void main(String[] args)
	{
		System.out.println("Hello Program");
		int X = 10;
		System.out.println("Hello Program"+X);

		
		int a = 10;
		int b = 5;
		int c = a/b;
		float d = a/b;
		float f = 7.9f;
		int k = 9;

		
		System.out.println(a+"/"+b+" = "+ c);	
		System.out.println(a+"/"+b+" = "+ d);	
		System.out.println("f = "+ f);	
		System.out.println("k = "+ k);
		
		int x=10;
		System.out.println("x = "+ x); 


	}
}