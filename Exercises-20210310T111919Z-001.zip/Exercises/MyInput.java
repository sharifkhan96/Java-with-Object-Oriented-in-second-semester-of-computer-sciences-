//Taking Input In Java

// There are many ways to take input in Java Programs

import java.util.Scanner;

public class MyInput
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		
		
		int marks;
		float GPA;	 

		System.out.print("Please Enter Marks : ");
		marks = input.nextInt();
		
		System.out.print("Please Enter GPA : ");
		GPA = input.nextFloat();

		System.out.println("You took : "+marks+" marks");
		marks++;
		marks++;

		System.out.println("Your marks after bonus of 2 : "+marks);
		System.out.println("Your GPA IS : "+GPA);
		
	}
}

