public class autoConversion
{
	public static void main(String[] args) 
    	{
		
		
		//WIDENING OR AUTOMATIC/IMPLICIT CONVERSION EXAMPLES
        
		int N1 = 100;  
          
        	// automatic type conversion 
	        long N2 = N1;  
          
	        // automatic type conversion 
	        float N3 = N2;
		System.out.println("\nWIDENING/IMPLICIT CONVERSION\n"); 
	        System.out.println("Int value   : "+N1); 
	        System.out.println("Long value  : "+N2); 
	        System.out.println("Float value : "+N3); 
		
		
		//NORROWING OR EXPLICIT CONVERSION
		System.out.println("\n\nNARROWING/EXPLICIT CONVERSION\n");
		double D = 120.04;  
          
        	//explicit type casting 
	        long L = (long)D; 
          
	        //explicit type casting  
	        int I = (int)L;  
	        System.out.println("Double value : "+D); 
          
	        //fractional part lost 
	        System.out.println("Long value : "+L);  
	          
	        //fractional part lost 
	        System.out.println("Int value "+I);
		
		
		//INT TO BYTE CONVERSION
		byte b;  
        	int i = 357;  
	        double d = 323.142; 
	        System.out.println("\nConversion of int to byte.");  
          
	        //i%256 
	        b = (byte) i;  
	        System.out.println("i = " + i + " b = " + b); 
	        System.out.println("\nConversion of double to byte."); 
	          
	        //d%256 
	        b = (byte) d;  
	        System.out.println("d = " + d + " b= " + b); 
    } 

}