//Taking Input in Java
//There are several ways to take input in java from Keyboard/File


import java.util.Scanner;

public class myInputProj
{
	public static void main(String[] args)
	{
		Scanner mySc = new Scanner(System.in);
		int age;
		System.out.print("Please Eneter Your Age :  ");		
		age = mySc.nextInt();

		System.out.println("Your Age is : "+age);
		
		age++;
		age++;

		System.out.println("You will be "+age+" years old after 2 Years");
	}
}