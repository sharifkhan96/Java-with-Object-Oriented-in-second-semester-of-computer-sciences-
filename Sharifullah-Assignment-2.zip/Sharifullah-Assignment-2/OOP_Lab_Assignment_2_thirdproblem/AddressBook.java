
package OOP_Lab_Assignment_2_thirdproblem;


public class AddressBook {

    static public void main(String []args){
    
AddressBook obj = new AddressBook();
Address objAdd = new Address("Third", "Jalalabad", "Nangarhar", 2603);
Specialperson objSPerson = new Specialperson(889774);

objSPerson.PrinInfo();


// actually all of this code(classes) is done by me but in driver class, sir i don't know how to proceed..
    
}
}