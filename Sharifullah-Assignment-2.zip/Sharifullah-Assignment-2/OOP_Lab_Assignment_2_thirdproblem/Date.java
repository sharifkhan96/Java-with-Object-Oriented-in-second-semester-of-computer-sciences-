
package OOP_Lab_Assignment_2_thirdproblem;


public class Date {
    
    Date(){
        System.out.println("Date Class will show you date...");
    }
    
    
    

String Day;
String Month;
String Year;

    public void setDay(String Day) {
        this.Day = Day;
    }

    public void setMonth(String Month) {
        this.Month = Month;
    }

    public void setYear(String Year) {
        this.Year = Year;
    }


    public String getDay(){
        return Day;
    }

    public String getMonth() {
        return Month;
    }

    public String getYear() {
        return Year;
    }
    
    
    
}
