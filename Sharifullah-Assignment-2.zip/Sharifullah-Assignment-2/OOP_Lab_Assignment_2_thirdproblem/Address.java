
package OOP_Lab_Assignment_2_thirdproblem;



public class Address {
    
    Address(String StreetAdd, String City, String State, int ZipCode){
        
        this.StreetAdd = StreetAdd;
        this.City = City;
        this.State = State;
        this.ZipCode = ZipCode;
    }

String StreetAdd;
String City;
String State;
int ZipCode;

public void PrintAdd(){
    System.out.println("Street Address is: "+ StreetAdd);
    System.out.println("City is: "+ City);
    System.out.println("State is: "+ State);
    System.out.println("Zip Code is: "+ ZipCode);
}

    
}
