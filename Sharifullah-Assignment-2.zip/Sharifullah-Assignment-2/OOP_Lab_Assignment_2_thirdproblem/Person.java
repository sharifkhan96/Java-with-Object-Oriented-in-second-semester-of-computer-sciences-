
package OOP_Lab_Assignment_2_thirdproblem;


public class Person {

// data members
String FName;
String LName;
char Gender;



    // setter
    public void setFName(String FName){
        this.FName = FName;
    }

    public void setLName(String LName) {
        this.LName = LName;
    }

    public void setGender(char Gender) {
        this.Gender = Gender;
    }
    
    
    // getters
    public String getFName(){
        return FName;
    }

    public String getLName() {
        return LName;
    }

    public char getGender() {
        return Gender;
    }
    
    


    
}
