
package OOP_Lab_Assignment_2_thirdproblem;
import java.util.Scanner;

public class Specialperson extends Person{
    
    Specialperson(int PNumber){
        this.PhoneNum = PNumber;
    }
    
    Date DOB = new Date();
    Address personAddress = new Address("Third", "Jalalabad", "Nangarhar", 2603);
    
    Scanner scan = new Scanner(System.in);
    int PhoneNum;
    

    
    public void classify(){
        
    int ClassifyPerson;
    System.out.print("1: Family member \n 2: Friend \n 3: Business Associate");
    ClassifyPerson = scan.nextInt();
    
    if(ClassifyPerson == 1){
        
        System.out.println("The person is your family member ");
        
    }else if(ClassifyPerson == 2){
        
        System.out.println("The person is your  friend ");
        
    }else if(ClassifyPerson == 3){
        
        System.out.println("The person is your business acquantance ");
        
    }else{
        
        System.out.println("The person is not known.. ");
        
    }
    
    
    }

   
    
    public void PrinInfo(){
        System.out.println("First Name: "+ FName);
        System.out.println("Last Name: "+ LName);
        System.out.println("Gender: "+ Gender);
        System.out.println("Day: "+ DOB.Day);
        System.out.println("Month: "+ DOB.Month);
        System.out.println("Year: "+ DOB.Year);
        System.out.println("Street Num: "+ personAddress.StreetAdd);
        System.out.println("City: "+ personAddress.City);
        System.out.println("State: "+ personAddress.State);
        System.out.println("Zip Code: "+ personAddress.ZipCode);
        classify();
        
    }


    
    
    
    
    
}
