
package OOP_Lab_Assignment_2_firstproblem;


public class SavingAccount extends Account{

private double defaultInterestRate = 2.5;
private double TinterestRAte;

Account obj = new Account();


    public void SetDefaultInterestRate(double interestRAte){
        this.defaultInterestRate  = interestRAte;
    }
    
    
    public void applyMonthlyInterest(){
        
        TinterestRAte = (obj.balance * defaultInterestRate) / 100 ;
        TinterestRAte = TinterestRAte * 30;
        System.out.println("Monthly interest rate is: "+ TinterestRAte);
    
}
    
    

}
