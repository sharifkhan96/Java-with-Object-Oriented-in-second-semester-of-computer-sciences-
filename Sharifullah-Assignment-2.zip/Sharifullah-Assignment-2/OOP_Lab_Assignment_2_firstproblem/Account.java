
package OOP_Lab_Assignment_2_firstproblem;


public class Account{

    protected double balance;
    
    public void deposit(double inAmount){

        balance = balance + inAmount;
        
        
    }

    
    public void withdraw(double inAmount){
        
        balance = balance - inAmount;
        
    }

}

