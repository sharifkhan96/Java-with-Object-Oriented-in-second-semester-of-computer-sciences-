
package OOP_Lab_Assignment_2_firstproblem;


public class MainClass {

    public static void main(String []args)
    {
        
    
    Account objAccount = new Account();
    SavingAccount objSAccount = new SavingAccount();

    
    objAccount.deposit(60);
    objAccount.withdraw(10);
    
    
    objSAccount.SetDefaultInterestRate(3);
    objSAccount.applyMonthlyInterest();
    
    // i don't know why the applymontlyinterest method is producing zero in the result..

    }
}
