
package OOP_Lab_Assignment_2_secondproblem;


public class OrderItem {
    
    Order objOrder = new Order();
    
    private String UPC;
    private int quantity;
    private int price;
    
    
    int getCost(){
        //return price * quantity;
        int total = price * quantity;
        return total;
    }

    @Override
    public String toString() {
        return "OrderItem{" + "objOrder=" + objOrder + ", UPC=" + UPC + ", quantity=" + quantity + ", price=" + price + '}';
    }
    
    
    
}
