
package OOP_Lab_Assignment_2_secondproblem;


public class RushOrder extends Order{

protected int deliveryday;
int noreturn;

public int getTotal(){
    
    super.getTotal();
    
    if(super.getTotal() == 0){
         noreturn = 0;
    }else{
         
        if(deliveryday >= 4){
            
            deliveryday = 0;
            
        }else if(deliveryday == 1){
            
            deliveryday = 25;
            
        }else if(deliveryday == 2){
            
            deliveryday = 15;
            
        }else{

            deliveryday = 10;
            
        }
    
   
}

   return deliveryday; 
}

}
