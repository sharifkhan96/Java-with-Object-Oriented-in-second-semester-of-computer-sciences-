
package OOP_Lab_Assignment_2_secondproblem;


public class Order {

OrderItem objOI[] = new OrderItem[3 ];


public void addOrderItem(//objOI :bjOI){
){
    
}

public int getTotal(){
    return 0;
}

 
public void printOrderItems(){
    
}

    @Override
    public String toString() {
        return "Order{" + "objOI=" + objOI + '}';
    }
    
    
}
