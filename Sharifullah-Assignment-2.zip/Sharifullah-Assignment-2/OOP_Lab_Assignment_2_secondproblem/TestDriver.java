
package OOP_Lab_Assignment_2_secondproblem;
import javax.swing.JOptionPane;
import java.util.Random;

public class TestDriver {
    
    public static void main(String []args){
    
    String UPC;
    //UPC = JOptionPane.showInputDialog(null, null, "Enter", null);
    
    Random objRandom = new Random();
    
     Order orders[] = new Order[4];
    
//    Order orders[0] = new Order();
//    OrderItem objOItem = new OrderItem();
//    RushOrder objROrder = new RushOrder();
    
        System.out.println("Price is "+ objRandom.doubles());
    
    
    // actually all of this code(classes) is done by me but in driver class, sir i don't know how to proceed..
    
    
    }
}
