import java.util.Scanner;

class Speed
{


	public static void main(String args[])
	{


	Scanner input = new Scanner(System.in);

	int option;
	double watersp = 4900;
	double airsp = 1100;
	double steelsp = 16400;
	double distance;
	double time;

	System.out.println("Enter what you want to calculate. water, air, steel: ");
	option = input.nextInt();
	System.out.println("Enter distance for specified option as well: ");
	distance = input.nextInt();

	if(option == 1)
	{
		
	time = distance / watersp;
	System.out.println("The amount of time for the speed of sound in the water could be: "+ time);		

	}else if(option == 2)
	{
	
	time = distance / airsp;
	System.out.println("The amount of time for the speed of sound in the air could be: "+ time);

	}else if(option == 3)
	{

	time = distance / steelsp;
	System.out.println("The amount of time for the speed of sound in the steel could be: "+ time);	

	}else
	{
		System.out.println("Your input is wrong...");
	}	








	}

}