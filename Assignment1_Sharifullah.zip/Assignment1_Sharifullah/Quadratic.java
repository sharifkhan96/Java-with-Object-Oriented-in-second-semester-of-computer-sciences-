
import java.util.Scanner;
import java.lang.Math;

public class Quadratic
{

    public static void main(String[] args) 
	{

        Scanner input=new Scanner(System.in);

        double a,b,c,x1,x2,Delta;

        System.out.println("Enter The Value for a: ");
        a=input.nextInt();

        System.out.println("Enter The Value For b: ");
        b=input.nextInt();

        System.out.println("Enter The Value For c: ");
        c=input.nextInt();

        Delta=b*b-4*a*c;
        System.out.println("The Value of Delta is= "+Delta);

        if(Delta >0)
	{
            System.out.println("System has two solutions...");

            x1=(-b+(Math.sqrt(Delta)))/2*a;
            x2=(-b-(Math.sqrt(Delta)))/2*a;

            System.out.println("X1= "+x1);
            System.out.println("X2= "+x2);
            
        }
        if(Delta==0)
	{
            
            System.out.println("System has only One solution.....");
        
	    x1=(-b+(Math.sqrt(Delta)))/2*a;
            x2=(-b-(Math.sqrt(Delta)))/2*a;
        
	    System.out.println("X1 = x2 which the value for x =  "+x1);
            System.out.println(" ");
        }
        if(Delta<0)
	{
            
            System.out.println("System has two imaginary solution...");
     
            x1=-b/2*a;
            x2=-b/2*a;
     
            System.out.println("x1 = "+ x1 +" + "+ Delta +" i ");
            System.out.println("x2= "+ x1 +" - "+ Delta +" i ");
        }
    

	}
}