import java.util.Scanner;

class Software
{

	public static void main(String args[])
	{

	Scanner input = new Scanner(System.in);	

	float packagep = 99;
	float howmany;
	int discount;
	double total;	
	
	System.out.println("The price of the software is: "+packagep);

	System.out.println("Enter how many packages are you going to buy: ");
	howmany = input.nextInt();

	if(howmany>9 && howmany<20)
	{
		discount = 20;
		total=howmany*packagep*.8;

		System.out.println("You get "+ discount +"% discount");
		System.out.println("You have to pay "+ total);	
	
	}else if(howmany>20 && howmany<50)
	{
		discount = 30;
		total=howmany*packagep*.7;
		
		System.out.println("You get "+ discount +"% discount");
		System.out.println("You have to pay "+ total);	
	
	}else if(howmany>49 && howmany<100)	
	{
		discount = 40;
		total=howmany*packagep*.6;
		
		System.out.println("You get "+ discount +"% discount");
		System.out.println("You have to pay "+ total);	
	
	}else if(howmany>=100)
	{
		discount = 50;	
		total=howmany*packagep*.5;
		
		System.out.println("You get "+ discount +"% discount");
		System.out.println("You have to pay "+ total);		

	}else
	{
		System.out.println("You cannot get any discount...");
		System.out.println("You have to pay "+ howmany*packagep);
	}


	}

}