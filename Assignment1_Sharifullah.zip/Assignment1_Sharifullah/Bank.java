
import java.util.Scanner;

class Bank
{


	public static void main(String args[])
	{


	Scanner input = new Scanner(System.in);

	

	int id, min, accbalance;
	char acc_type;
	int current_fine = 2500;
	int saving_fine = 1000;
	double total;
	int n=1;
	
	

	// =========Upto here we are gonna take input from the user including: account id, account type, minimum balance, account balance of the customer=========
	

	System.out.print("Enter your account id number: ");
	id = input.nextInt();
	
	System.out.print("Enter your account type, S for saving & C for current: ");
	acc_type = input.next().charAt(0);

	
	System.out.print("Enter minimum account balance: ");
	min = input.nextInt();

	
	System.out.print("Enter your account balance: ");
	accbalance = input.nextInt();	



	
	//===Now we are fining them in case the account balance is below the minimum balance===
	

	if(acc_type=='C' || acc_type=='c' && accbalance < min)
	{	
		accbalance -= current_fine;
		System.out.print("You are fine 2,500: "+ accbalance);

	}
	else if(acc_type=='S' || acc_type=='s' && accbalance < min)
	{
		accbalance -= saving_fine;
		System.out.println("You are fined 1000: "+ accbalance);
	}		
	else if(acc_type=='S' || acc_type=='s' && accbalance>=min)
	{
		//=====we are giving them interest if the balance is equal to the minimum=====
		
		total = (accbalance*1.0033333333)^1;
		System.out.println("You have got 4% of interest: "+total);

	}
	else if(acc_type=='C' || acc_type=='c' &&  accbalance<=5000)
	{
		total = (accbalance*1.0025)^1;
		System.out.println("You have gotten 3% of interest: "+total);

	}else
	{
		total = (accbalance*1.00416667)^1;
		System.out.println("You have gotten 5% of interest: "+total);
	}        
	






	}


}