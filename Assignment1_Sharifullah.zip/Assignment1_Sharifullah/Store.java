import java.util.Scanner;

class Store
{

	public static void main(String args[])
	{
	
	Scanner input = new Scanner(System.in);
	
	int  SIZE = 5;
	int[] sale = new int[SIZE];
	
	for(int j=0; j<SIZE; j++)
	{
		System.out.print("Enter sale number "+(j+1)+": ");
		sale[j] = input.nextInt();
	}


//	===============================================

	System.out.println("\n\n Sales Bar Chart");	

	System.out.print("Sale 1: ");
	for(int j=0; j<(sale[0]/100);j++)
	{
	System.out.print("*");
	}

	System.out.println("");
	
	System.out.print("Sale 2: ");
	for(int i=0; i<(sale[1]/100); i++)
	{
		System.out.print("*");
	}
	
	System.out.println("");	
	
	System.out.print("Sale 3: ");
	for(int i=0; i<(sale[2]/100); i++)
	{
		System.out.print("*");
	}

	System.out.println("");	
	
	System.out.print("Sale 4: ");	
	for(int i=0; i<(sale[3]/100); i++)
	{
		System.out.print("*");
	}
	
	System.out.println("");	
	
	System.out.print("Sale 5: ");
	for(int i=0; i<(sale[4]/100); i++)
	{
		System.out.print("*");
	}	
	



	}

}